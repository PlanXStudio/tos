# Terminitor plugin

This plugin adds completions for the [Terminitor](https://github.com/achiurizo/terminitor) development workflow setup tool.

To use it, add `terminitor` to the plugins array in your zshrc file:

```zsh
plugins=(... terminitor)
```
